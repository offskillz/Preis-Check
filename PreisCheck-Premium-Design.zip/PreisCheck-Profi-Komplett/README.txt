PREISCHECK – PROFI KOMPLETT
===========================

Bereits umgesetzt:
- professionelles Shopping-App-Design
- Produktsuche
- Produktvergleich
- Foto-Upload mit Server-Endpoint für KI-Erkennung
- Barcode-Workflow vorbereitet
- Preisalarm-/Favoriten-Oberfläche
- serverseitige API-Struktur
- Amazon Creators API Integration vorbereitet
- keine API-Schlüssel im Frontend

Für echte Live-Daten noch erforderlich:
1. OpenAI API-Key für die Bildanalyse
2. Amazon Creators API Zugang + Partner Tag
3. weitere zulässige Preis-/Affiliate-Datenquellen für zusätzliche Händler
4. HTTPS-Hosting für den Online-Betrieb

Amazon hat PA-API 5 deprecated und verweist auf die Creators API. Die Creators API verwendet OAuth 2.0; Credentials gehören ausschließlich auf den Server.
Google Merchant API ist für Merchant-Center-Daten gedacht und benötigt ein Merchant-Center-Konto sowie ein verknüpftes Google-Cloud-Projekt. Sie ist daher nicht einfach eine öffentliche Google-Shopping-Such-API.

Live-Preise werden nicht erfunden.
